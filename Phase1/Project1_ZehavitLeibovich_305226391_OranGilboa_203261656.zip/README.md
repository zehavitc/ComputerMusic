# ComputerMusic
RGB Music

1. Run 'onServer.scd' on SuperCollider
2. Run 'project.py' with python
