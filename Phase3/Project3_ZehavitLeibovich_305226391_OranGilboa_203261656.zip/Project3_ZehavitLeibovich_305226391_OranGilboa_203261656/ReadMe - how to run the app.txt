1. Run the file "onServer-phase3.scd" on a SC server
2. Run project-phase3.py using python2.7 (Read requirements.txt for python requirements)
